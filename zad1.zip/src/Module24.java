import java.time.LocalTime;

public class Module24 implements Module{
    public String Time(){
        return LocalTime.now().format(f24);
    }
}
