public class Watch {
    private Module mod12;
    private Module mod24;
    private Module activemod;
    public Watch(Module mod12,Module mod24){
        this.mod12=mod12;
        this.mod24=mod24;
        this.activemod=mod24;
    }
    public void functionA(){
        System.out.println(activemod.Time());
    }
    public void nextModule(){
        if(activemod==mod12){
            activemod=mod24;
        }
        else{
            activemod=mod12;
        }
    }
}
