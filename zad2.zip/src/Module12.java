import java.time.LocalTime;

public class Module12 implements Module {
    public String Time(){
        return LocalTime.now().format(f12);
    }

}
