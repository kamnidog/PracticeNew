
import java.time.format.DateTimeFormatter;

public interface Module {
    DateTimeFormatter f24= DateTimeFormatter.ofPattern("HH:mm:ss");
    DateTimeFormatter f12= DateTimeFormatter.ofPattern("hh:mm:ss a");
    public String Time();

}
