public class Watch {
    private int active=0;
    private Module[] mods;
    public Watch(Module[] mods){
        this.mods=mods;
    }
    public void functionA(){
        System.out.println(mods[active].Time());
    }
    public void nextModule(){
        if(active+1< mods.length){
            active++;
        }
        else{
            active=0;
        }
    }
}
